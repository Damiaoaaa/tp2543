<?php
 
 $servername="lrgs.ftsm.ukm.my";
  $username="a184539";
  $password="littlepinkfrog";
  $dbname="a184539";
 
?>