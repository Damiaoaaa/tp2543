<!DOCTYPE html>
<html>
<head>
	<title>My Book Ordering System</title>
</head>
<body>
	<center>
<a href="index.php">Home</a> |
<a href="products.php">Products</a> |
<a href="customers.php">Customers</a> |
<a href="staffs.php">Staffs</a> |
<a href="orders.php">Orders</a>
<hr>
</center>
</body>
</html>