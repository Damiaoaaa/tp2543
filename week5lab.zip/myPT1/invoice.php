<!DOCTYPE html>
<html>
<head>
  <title>My Booking Ordering System : Invoice</title>
</head>
<body>
  <center>
    My Bike Sdn. Bhd. <br>
    Address 1 <br>
    Address 2 <br>
    Postcode <br>
    State <br>
    <hr>
    Order ID: O5603f03a9349f0.39900158
    Order Date: 09-09-2015
    <hr>
    Staff: James Martin
    Customer: Maria Garcia
    Date: Today
    <hr>
    <table border="1">
      <tr>
        <td>No</td>
        <td>Product</td>
        <td>Quantity</td>
        <td>Price(RM)/Unit</td>
        <td>Total(RM)</td>
      </tr>
      <tr>
        <td>1</td>
        <td>Concours 14 Abs</td>
        <td>1</td>
        <td>16199</td>
        <td>16199</td>
      </tr>
      <tr>
        <td>2</td>
        <td>Versys 650 Lt</td>
        <td>2</td>
        <td>7599</td>
        <td>15198</td>
      </tr>
      <tr>
        <td colspan="4" align="right">Grand Total</td>
        <td>31397</td>
      </tr>
    </table>
    <hr>
    Computer-generated invoice. No signature is required.
  </center>
</body>
</html>