<!DOCTYPE html>
<html>
<head>
  <title>My Booking Ordering System : Products Details</title>
</head>
<body>
  <center>
    <a href="index.php">Home</a> |
    <a href="products.php">Products</a> |
    <a href="customers.php">Customers</a> |
    <a href="staffs.php">Staffs</a> |
    <a href="orders.php">Orders</a>
    <hr>
    Product ID: 001 <br>
    Name: Alice's Adventures in Wonderland: Annotated  <br>
    Type: Fantasy <br>
    Published: November 1865 <br>
    Language: English <br>
    Author: Lewis Carroll <br>
    Price: $ 22.00 <br>
    <img src="products/P001.png" width="50%" height="50%">
  </center>
</body>
</html>